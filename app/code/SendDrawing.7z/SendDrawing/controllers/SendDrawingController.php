<?php
class M2ITS_SendDrawing_SendDrawingController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
//        $this->loadLayout();
//        $this->renderLayout();

        $this->_title('Wysłane rysunki');
        $this->loadLayout();
        $this->_setActiveMenu('senddrawing/index');
        $this->_addContent($this->getLayout()->createBlock('senddrawing/adminhtml_SendDrawing'));
//        echo gettype();

        $this->renderLayout();
    }
//
    public function gridAction()
    {
        $this->loadLayout();
        $this->getResponse()->setBody(
            $this->getLayout()->createBlock('senddrawing/adminhtml_SendDrawing')->toHtml()
            );
    }

    public function exportDrawingCsvAction()
    {
        $fileName = 'sent_drawings.csv';
        $grid = $this->getLayout()->createBlock('senddrawing/adminhtml_SendDrawing');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }

    public function exportDrawingExcelAction()
    {
        $fileName = 'sent_drawings.xml';
        $grid = $this->getLayout()->createBlock('senddrawing/adminhtml_SendDrawing');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }
}