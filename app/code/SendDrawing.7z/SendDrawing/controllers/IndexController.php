<?php
class M2ITS_SendDrawing_IndexController extends Mage_Core_Controller_Front_Action
{

    const XML_PATH_EMAIL_RECIPIENT = 'contacts/email/recipient_email';
    const XML_PATH_EMAIL_SENDER = 'contacts/email/sender_email_identity';

    public function IndexAction()
    {
	  $this->loadLayout();
      $this->renderLayout();
    }

    public function PostAction()
    {
        $post = $this->getRequest()->getPost();

        if($post) {
            try {

                if (!Zend_Validate::is(trim($post['drawing_email']), 'EmailAddress')) {
                    echo json_encode(['error' => 'email']);
                    return false;
                }

                if (!Zend_Validate::is(trim($post['drawing_name']), 'NotEmpty')) {
                    echo json_encode(['error' => 'name']);
                    return false;
                }

                $name = htmlspecialchars($post['drawing_name']);
                $email = htmlspecialchars($post['drawing_email']);
                $zip_code = $post['drawing_zip'] != "" ? htmlspecialchars($post['drawing_zip']) : "Brak";
                $city = $post['drawing_city'] != "" ? htmlspecialchars($post['drawing_city']) : "Brak";
                $phone_number = $post['drawing_phone'] != "" ? htmlspecialchars($post['drawing_phone']) : 0000000000;
                $accepted = $post['drawing_agreement'] == "on" ? 1 : 0;


                $attribute_name = htmlspecialchars($post['attribute_name']);
                $id_product = htmlspecialchars($post['id']);

                $_drawing = Mage::getModel('senddrawing/drawing');

                $_drawing->addData([
                    'name' => $name,
                    'email' => $email,
                    'zip_code' => $zip_code,
                    'city' => $city,
                    'phone_number' => $phone_number,
                    'accepted' => $accepted,
                    'id_product' => (int) $id_product,
                    'type' => $attribute_name,
                    'download_date' => date('Y-m-d H:i:s')
                    ]);
                $_drawing->save();


                $_product = Mage::getModel('catalog/product')->load((int)$id_product);
                $resource = $_product->getResource()->getAttribute($attribute_name)->getFrontend()->getValue($_product);
                $rendered_url = Mage::helper('macopedia_import')->getProductFileUrl($resource);

                /* SEND MAIL SECTION */
                $emailTemplate = Mage::getModel('core/email_template');
                $templateId = $emailTemplate->loadByCode('Zamow rysunek');

                /* @var $emailTemplate Mage_Core_Model_Email_Template */
                $emailTemplate
                    ->sendTransactional(
                        Mage::getStoreConfig($templateId),
                        Mage::getStoreConfig(self::XML_PATH_EMAIL_SENDER),
                        $email,
                        $name,
                        ['url' => $rendered_url]
                    );
//                if(!$emailTem?plate->getSentSuccess()) echo json_encode(['error' => 'mail_not_sent']);

                echo json_encode(['status' => 'done']);
                return true;
            } catch (Exception $e) {
                echo json_encode(['error'=>$e->getMessage()]);
                return false;
            }
        }

        $this->_redirect('*/*/');
        return false;
    }
}