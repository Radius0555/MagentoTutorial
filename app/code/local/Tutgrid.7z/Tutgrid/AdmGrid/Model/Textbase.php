<?php

class Tutgrid_AdmGrid_Model_Textbase extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _contruct()
    {
        $this->_init('admgrid/textbase');
    }
}
