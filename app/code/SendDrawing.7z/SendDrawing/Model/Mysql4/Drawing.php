<?php
class M2ITS_SendDrawing_Model_Mysql4_Drawing extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("senddrawing/drawing", "m2is_drawing_id");
    }
}