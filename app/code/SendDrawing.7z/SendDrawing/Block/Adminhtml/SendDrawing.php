<?php
class M2ITS_SendDrawing_Block_Adminhtml_SendDrawing extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_blockGroup = 'senddrawing';
        $this->_controller = 'adminhtml_SendDrawing';
        $this->_headerText = "Wysłane rysunki szczegółowe";

        parent::__construct();
        $this->_removeButton('add');
    }
}