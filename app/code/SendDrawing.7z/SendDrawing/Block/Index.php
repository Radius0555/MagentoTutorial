<?php
class M2ITS_SendDrawing_Block_Index extends Mage_Core_Block_Template{





}