<?php

class M2ITS_SendDrawing_Model_Drawing extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("senddrawing/drawing");

    }

}
	 