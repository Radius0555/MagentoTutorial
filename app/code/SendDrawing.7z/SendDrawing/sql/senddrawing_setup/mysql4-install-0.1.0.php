<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table m2its_drawing(
    m2its_drawing_id int not null auto_increment, 
    name varchar(100), 
    email varchar(100), 
    zip_code varchar(100), 
    city varchar(100), 
    phone_number int(55), 
    accepted int(10), 
    download_date datetime not null,
    id_product int(55) not null,
    type varchar(55) not null,
    primary key(m2its_drawing_id)) ENGINE='InnoDB' COLLATE 'utf8_bin';
		
SQLTEXT;

$installer->run($sql);
//demo
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 